package com.yu.share;

/**
 * @author yudneghao
 * @date 2019-04-30
 */
final public class Key {
  public static final String WX_APP_ID = "wxb9892c638e16cdca";
  public static final String WX_APP_KEY = "e9a7f5b40de51c3c3c7fa9a8b9cc7624";


  public static final String QQ_APPID = "";
  public static final String QQ_APP_KEY = "";
}
