package com.yu.share.wxapi;

import com.umeng.socialize.weixin.view.WXCallbackActivity;

/**
 * @author yudneghao
 * @date 2019/4/15
 */
public class WXEntryActivity extends WXCallbackActivity {
}
